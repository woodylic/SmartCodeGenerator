﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

public partial class Pop : System.Web.UI.MasterPage
{

    public string RootUrl
    {
        get
        {
            string AppPath = "";
            HttpContext HttpCurrent = HttpContext.Current;
            HttpRequest Req;
            if (HttpCurrent != null)
            {
                Req = HttpCurrent.Request;

                string UrlAuthority = Req.Url.GetLeftPart(UriPartial.Authority);
                if (Req.ApplicationPath == null || Req.ApplicationPath == "/")
                    AppPath = UrlAuthority;
                else
                    AppPath = UrlAuthority + Req.ApplicationPath;
            }
            return AppPath;
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
            HtmlGenericControl easyuiLink = new HtmlGenericControl("LINK");
            easyuiLink.ID = ID;
            easyuiLink.Attributes["rel"] = "stylesheet";
            easyuiLink.Attributes["type"] = "text/css";
            easyuiLink.Attributes["href"] = Server.HtmlDecode(RootUrl) + @"/App_Themes/default/easyui.css";
            this.PageCSS.Controls.Add(easyuiLink);

            HtmlGenericControl iconLink = new HtmlGenericControl("LINK");
            iconLink.ID = ID;
            iconLink.Attributes["rel"] = "stylesheet";
            iconLink.Attributes["type"] = "text/css";
            iconLink.Attributes["href"] = Server.HtmlDecode(RootUrl) + @"/App_Themes/icon.css";
            this.PageCSS.Controls.Add(iconLink);

            HtmlGenericControl BYCommonLink = new HtmlGenericControl("LINK");
            BYCommonLink.ID = ID;
            BYCommonLink.Attributes["rel"] = "stylesheet";
            BYCommonLink.Attributes["type"] = "text/css";
            BYCommonLink.Attributes["href"] = Server.HtmlDecode(RootUrl) + @"/App_Themes/default/BYCommon.css";
            this.PageCSS.Controls.Add(BYCommonLink);

            HtmlGenericControl autocompleteLink = new HtmlGenericControl("LINK");
            autocompleteLink.ID = ID;
            autocompleteLink.Attributes["rel"] = "stylesheet";
            autocompleteLink.Attributes["type"] = "text/css";
            autocompleteLink.Attributes["href"] = Server.HtmlDecode(RootUrl) + @"/App_Themes/default/jquery.autocomplete.css";
            this.PageCSS.Controls.Add(autocompleteLink);

            HtmlGenericControl jquery_Link = new HtmlGenericControl("script");
            jquery_Link.ID = ID;
            jquery_Link.Attributes["type"] = "text/javascript";
            jquery_Link.Attributes["language"] = "javascript";
            jquery_Link.Attributes["src"] = Server.HtmlDecode(RootUrl) + @"/Scripts/jquery-1.4.4.min.js";
            this.PageCSS.Controls.Add(jquery_Link);

            HtmlGenericControl easyui_Link = new HtmlGenericControl("script");
            easyui_Link.ID = ID;
            easyui_Link.Attributes["type"] = "text/javascript";
            easyui_Link.Attributes["language"] = "javascript";
            easyui_Link.Attributes["src"] = Server.HtmlDecode(RootUrl) + @"/Scripts/jquery.easyui.min.js";
            this.PageCSS.Controls.Add(easyui_Link);

            HtmlGenericControl easyloader_Link = new HtmlGenericControl("script");
            easyloader_Link.ID = ID;
            easyloader_Link.Attributes["type"] = "text/javascript";
            easyloader_Link.Attributes["language"] = "javascript";
            easyloader_Link.Attributes["src"] = Server.HtmlDecode(RootUrl) + @"/Scripts/easyloader.js";
            this.PageCSS.Controls.Add(easyloader_Link);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HP.Web.Controls
{
    public class SmartGridView : GridView
    {
        /// <summary>
        /// Custom record count
        /// </summary>
        public long CustomRecordCount
        {
            get
            {
                if (ViewState["gv_CustomRecordCount"] == null)
                {
                    ViewState["gv_CustomRecordCount"] = 0;
                }
                return long.Parse(ViewState["gv_CustomRecordCount"].ToString());
            }
            set
            {
                ViewState["gv_CustomRecordCount"] = value;
            }
        }

        /// <summary>
        /// Custom page index
        /// </summary>
        public int CustomPageIndex
        {
            get
            {
                if (ViewState["gv_CustomPageIndex"] == null)
                {
                    ViewState["gv_CustomPageIndex"] = 0;
                }
                return (int)ViewState["gv_CustomPageIndex"];
            }
            set
            {
                ViewState["gv_CustomPageIndex"] = value;
            }
        }
        public string PaggerModel
        {
            get
            {
                if (ViewState["PaggerModel"] == null)
                {
                    ViewState["PaggerModel"] = "DropDownList";
                }
                return ViewState["PaggerModel"].ToString();
            }
            set
            {
                ViewState["PaggerModel"] = value;
            }
        }
        public string Culture
        {
            get
            {
                if (ViewState["Culture"] == null)
                {
                    ViewState["Culture"] = "CN";
                }
                return ViewState["Culture"].ToString();
            }
            set
            {
                ViewState["Culture"] = value;
            }
        }

        public string CustomSortExpression
        {
            get
            {
                if (ViewState["gv_CustomSortExpression"] == null)
                {
                    ViewState["gv_CustomSortExpression"] = string.Empty;
                }
                return ViewState["gv_CustomSortExpression"].ToString();
            }
            set
            {
                ViewState["gv_CustomSortExpression"] = value;
            }
        }
        public string CustomSortDirection
        {
            get
            {
                if (ViewState["gv_CustomSortDirection"] == null)
                {
                    ViewState["gv_CustomSortDirection"] = string.Empty;
                }
                return ViewState["gv_CustomSortDirection"].ToString();
            }
            set
            {
                ViewState["gv_CustomSortDirection"] = value;
            }
        }
        public void SetSortDirection()
        {
            if (this.CustomSortDirection == string.Empty)
            {
                this.CustomSortDirection = SortDirection.Ascending.ToString();
            }
            else
            {
                if (this.CustomSortDirection == SortDirection.Ascending.ToString())
                {
                    this.CustomSortDirection = SortDirection.Descending.ToString();
                }
                else if (this.CustomSortDirection == SortDirection.Descending.ToString())
                {
                    this.CustomSortDirection = SortDirection.Ascending.ToString();
                }
            }
        }
        public string GetSortDirection()
        {
            if (this.CustomSortDirection == SortDirection.Ascending.ToString())
            {
                return "asc";
            }
            else if (this.CustomSortDirection == SortDirection.Descending.ToString())
            {
                return "desc";
            }
            return string.Empty;
        }
        public bool AllowCustomPageSize { get; set; }
        private bool m_ShowSerialNumberColumn = false;
        public bool ShowSerialNumberColumn
        {
            get
            {
                return m_ShowSerialNumberColumn;
            }
            set
            {
                m_ShowSerialNumberColumn = value;
            }
        }
        private int m_SerialNumberColumnIndex = 0;
        public int SerialNumberColumnIndex
        {
            get
            {
                return m_SerialNumberColumnIndex;
            }
            set
            {
                m_SerialNumberColumnIndex = value;
            }
        }

        public void SetRowDefaultBehavior(GridViewRow row, string dblClickUrl)
        {
            row.Attributes.Add("onmouseover", string.Format("{0}( this, '{1}' ); ", "setBgColor", "#FAFAD2"));
            row.Attributes.Add("onmouseout", string.Format("{0}( this ); ", "setBgColorBack"));
            if (!string.IsNullOrEmpty(dblClickUrl))
            {
                row.Attributes.Add("ondblclick",
                    string.Format("{0}( this, '{1}' ); window.location.href='{2}'; ", "setBgReactColor", "#FFFFA0", dblClickUrl));
            }
        }

        public SmartGridView()
        {
        }

        string noDataMsg = string.Empty;
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            if (!this.DesignMode)
            {
                this.GridLines = GridLines.None;
                this.AutoGenerateColumns = false;

                if (this.ShowSerialNumberColumn)
                {
                    BoundField bf = new BoundField();
                    bf.HeaderText = "#";
                    bf.HeaderStyle.Width = Unit.Pixel(15);
                    bf.ItemStyle.Width = Unit.Pixel(15);
                    bf.ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                    this.Columns.Insert(this.SerialNumberColumnIndex, bf);
                }

                if (!string.IsNullOrEmpty(this.Caption))
                {
                    this.Caption = string.Format("<div>{0}</div>", this.Caption);
                }

                noDataMsg += "<tbody><tr class=\"head\">";
                for (int i = 0; i < this.Columns.Count; i++)
                {
                    DataControlField dcf = this.Columns[i];

                    if (dcf is BoundField)
                    {
                        ((BoundField)dcf).HtmlEncode = false;
                    }
                    dcf.HeaderText = string.Format("<div>{0}</div>", dcf.HeaderText);
                    noDataMsg += string.Format("<th scope=\"col\">{0}</th>", dcf.HeaderText);
                }
                noDataMsg += "</tr></tbody>";
                noDataMsg += string.Format("<tr><td colspan='{0}'>No items.</td></tr>", this.Columns.Count);


                this.PreRender += new EventHandler(SmartGridView_PreRender);
                this.RowCreated += new GridViewRowEventHandler(SmartGridView_RowCreated);
                this.RowCommand += new GridViewCommandEventHandler(SmartGridView_RowCommand);
            }
        }

        void SmartGridView_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "CustomPage")
            {
                if (e.CommandArgument.ToString() == "First")
                {
                    this.CustomPageIndex = 0;
                }
                else if (e.CommandArgument.ToString() == "Prev")
                {
                    this.CustomPageIndex = this.CustomPageIndex - 1;
                }
                else if (e.CommandArgument.ToString() == "Next")
                {
                    this.CustomPageIndex = this.CustomPageIndex + 1;
                }
                else if (e.CommandArgument.ToString() == "Last")
                {
                    long recordCount = this.CustomRecordCount;
                    int pageCount = (int)Math.Ceiling((double)recordCount / (double)this.PageSize);
                    this.CustomPageIndex = pageCount - 1;
                }
                this.OnPageChanged(sender, EventArgs.Empty);
            }
        }

        void SmartGridView_PreRender(object sender, EventArgs e)
        {
            if (this.AllowPaging)
            {
                GridViewRow pageRow = this.BottomPagerRow;
                if (pageRow != null)
                {
                    pageRow.Visible = true;
                }
            }
        }

        void SmartGridView_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                if (this.AllowSorting)
                {
                    for (int i = 0; i < this.Columns.Count; i++)
                    {
                        DataControlField dcf = this.Columns[i];

                        if (!string.IsNullOrEmpty(dcf.SortExpression))
                        {
                            string text = ((LinkButton)e.Row.Cells[i].Controls[0]).Text;
                            if (!string.IsNullOrEmpty(this.CustomSortExpression) && this.CustomSortExpression == dcf.SortExpression)
                            {
                                e.Row.Cells[i].CssClass = "sorted";
                                if (this.CustomSortDirection == SortDirection.Ascending.ToString())
                                {
                                    if (text.StartsWith("<div class=\"sdesc\">"))
                                    {
                                        text = text.Replace("<div class=\"sdesc\">", "<div class=\"sasc\">");
                                    }
                                    else
                                    {
                                        text = text.Replace("<div>", "<div class=\"sasc\">");
                                    }
                                }
                                else if (this.CustomSortDirection == SortDirection.Descending.ToString())
                                {
                                    if (text.StartsWith("<div class=\"sasc\">"))
                                    {
                                        text = text.Replace("<div class=\"sasc\">", "<div class=\"sdesc\">");
                                    }
                                    else
                                    {
                                        text = text.Replace("<div>", "<div class=\"sdesc\">");
                                    }
                                }
                            }
                            else
                            {
                                text = text.Replace("<div class=\"sasc\">", "<div>")
                                    .Replace("<div class=\"sdesc\">", "<div>");
                            }
                            ((LinkButton)e.Row.Cells[i].Controls[0]).Text = text;
                        }
                    }
                }
            }
            else if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (this.ShowSerialNumberColumn)
                {
                    e.Row.Cells[this.SerialNumberColumnIndex].Text = (this.PageSize * this.CustomPageIndex + e.Row.DataItemIndex + 1).ToString();
                }
            }
            else if (e.Row.RowType == DataControlRowType.EmptyDataRow)
            {
                // no data show message.
                if (this.CustomRecordCount == 0)
                {
                    e.Row.Controls.Clear();
                    TableCell tc = new TableCell();
                    tc.Controls.Add(new LiteralControl(noDataMsg));
                    tc.ColumnSpan = this.Columns.Count;
                    e.Row.Controls.Add(tc);
                }
            }
            else if (e.Row.RowType == DataControlRowType.Pager)
            {
                if (this.AllowPaging)
                {
                    e.Row.Controls.Clear();

                    TableCell tc = new TableCell();

                    Button btnFirst = new Button();
                    Button btnPrev = new Button();
                    Button btnNext = new Button();
                    Button btnLast = new Button();

                    long recordCount = this.CustomRecordCount;
                    int pageCount = (int)Math.Ceiling((double)recordCount / (double)this.PageSize);

                    tc.Controls.Add(new LiteralControl("<div style=\"width: 100%\" class=\"pager\"><div class=\"pDiv\"><div class=\"pGroup\">"));

                    btnFirst.CommandName = "CustomPage";
                    btnFirst.CommandArgument = "First";
                    btnFirst.CssClass = "pFirst pButton";
                    btnFirst.CausesValidation = false;

                    btnPrev.CommandName = "CustomPage";
                    btnPrev.CommandArgument = "Prev";
                    btnPrev.CssClass = "pPrev pButton";
                    btnPrev.CausesValidation = false;

                    btnNext.CommandName = "CustomPage";
                    btnNext.CommandArgument = "Next";
                    btnNext.CssClass = "pNext pButton";
                    btnNext.CausesValidation = false;

                    btnLast.CommandName = "CustomPage";
                    btnLast.CommandArgument = "Last";
                    btnLast.CssClass = "pLast pButton";
                    btnLast.CausesValidation = false;

                    if (this.CustomPageIndex == 0)
                    {
                        btnFirst.CssClass = "pFirstDis pButton";
                        btnFirst.Enabled = false;
                        btnPrev.CssClass = "pPrevDis pButton";
                        btnPrev.Enabled = false;
                    }
                    if (this.CustomPageIndex == pageCount - 1)
                    {
                        btnNext.CssClass = "pNextDis pButton";
                        btnNext.Enabled = false;
                        btnLast.CssClass = "pLastDis pButton";
                        btnLast.Enabled = false;
                    }

                    tc.Controls.Add(btnFirst);
                    tc.Controls.Add(btnPrev);

                    tc.Controls.Add(new LiteralControl("</div><div class=\"btnseparator\"></div><div class=\"pGroup\">"));
                    Control pageIndex = null;
                    if (this.PaggerModel == "TextBox")
                    {
                        TextBox txtPageIndex = new TextBox();
                        txtPageIndex.Attributes.Add("size", "1");
                        txtPageIndex.Text = (this.CustomPageIndex + 1).ToString();
                        txtPageIndex.CssClass = "txt";
                        txtPageIndex.AutoPostBack = true;
                        txtPageIndex.TextChanged += new EventHandler(txtPageIndex_TextChanged);
                        pageIndex = txtPageIndex;
                        tc.Controls.Add(new LiteralControl("<div class=\"pGroupChild\"><span class=\"pcontrol\">Page</span></div>"));
                        tc.Controls.Add(new LiteralControl("<div class=\"pGroupChild\">"));
                        tc.Controls.Add(pageIndex);
                        tc.Controls.Add(new LiteralControl("</div>"));
                        tc.Controls.Add(new LiteralControl(string.Format("<div class=\"pGroupChild\"><span class=\"pcontrol\">of {0}</span></div>", pageCount)));

                    }
                    if (string.IsNullOrEmpty(this.PaggerModel) || this.PaggerModel == "DropDownList")
                    {
                        DropDownList ddlPageIndex = new DropDownList();
                        for (int i = 1; i <= pageCount; i++)
                        {
                            ddlPageIndex.Items.Add(new ListItem(i.ToString(), (i - 1).ToString()));
                        }
                        ddlPageIndex.AutoPostBack = true;
                        ddlPageIndex.SelectedIndexChanged += new EventHandler(ddlPageIndex_SelectedIndexChanged);
                        ddlPageIndex.SelectedIndex = this.CustomPageIndex;
                        pageIndex = ddlPageIndex;
                        tc.Controls.Add(pageIndex);
                    }
                    tc.Controls.Add(new LiteralControl("</div><div class=\"btnseparator\"></div><div class=\"pGroup\">"));

                    tc.Controls.Add(btnNext);
                    tc.Controls.Add(btnLast);
                    int currentPageListStart = this.CustomPageIndex * this.PageSize + 1;
                    int currentPageListEnd = currentPageListStart + this.Rows.Count - 1; //(this.CustomPageIndex + 1) * this.PageSize - 1;
                    tc.Controls.Add(new LiteralControl("</div><div class=\"btnseparator\"></div><div class=\"pGroup\">"));
                    if (this.AllowCustomPageSize)
                    {
                        DropDownList ddlPagePerCount = new DropDownList();
                        ddlPagePerCount.Items.Add(new ListItem("10"));
                        ddlPagePerCount.Items.Add(new ListItem("15"));
                        ddlPagePerCount.Items.Add(new ListItem("20"));
                        ddlPagePerCount.Items.Add(new ListItem("25"));
                        ddlPagePerCount.Items.Add(new ListItem("40"));
                        ddlPagePerCount.Items.Add(new ListItem("100"));
                        ddlPagePerCount.AutoPostBack = true;
                        ddlPagePerCount.SelectedIndexChanged += new EventHandler(ddlPagePerCount_SelectedIndexChanged);
                        ddlPagePerCount.SelectedValue = this.PageSize.ToString();
                        //if (this.Culture == "EN")
                        //{
                        //    tc.Controls.Add(new LiteralControl("<div class=\"pGroup\"><span class=\"pPageStat\">Page Size</span></div>"));
                        //}
                        //else
                        //{
                        //    tc.Controls.Add(new LiteralControl("<div class=\"pGroup\"><span class=\"pPageStat\">页面大小</span></div>"));
                        //}
                        tc.Controls.Add(ddlPagePerCount);

                    }
                    if (this.Culture == "EN")
                    {
                        tc.Controls.Add(new LiteralControl(string.Format("</div><div class=\"btnseparator\"></div><div class=\"pGroup\"><span class=\"pPageStat\">Displaying {0} to {1} of {2} items</span></div>",
                            currentPageListStart, currentPageListEnd, recordCount)));
                    }
                    else if (this.Culture == "CN")
                    {
                        tc.Controls.Add(new LiteralControl(string.Format("</div><div class=\"btnseparator\"></div><div class=\"pGroup\"><span class=\"pPageStat\">当前显示 {0}-{1} 条，总共 {2} 条</span></div>",
                           currentPageListStart, currentPageListEnd, recordCount)));
                    }
                    else
                    {
                        tc.Controls.Add(new LiteralControl(string.Format("</div><div class=\"btnseparator\"></div><div class=\"pGroup\"><span class=\"pPageStat\">当前显示 {0}-{1} 条，总共 {2} 条</span></div>",
                            currentPageListStart, currentPageListEnd, recordCount)));
                    }
                    tc.Controls.Add(new LiteralControl("</div><div style=\"clear: both\"></div></div>"));

                    tc.ColumnSpan = this.Columns.Count;
                    e.Row.Controls.Add(tc);
                }
            }
        }

        void txtPageIndex_TextChanged(object sender, EventArgs e)
        {
            long recordCount = this.CustomRecordCount;
            int pageCount = (int)Math.Ceiling((double)recordCount / (double)this.PageSize);
            int tempPageIndex = 0;
            TextBox txtPageIndex = sender as TextBox;
            if (int.TryParse(txtPageIndex.Text, out tempPageIndex))
            {
                if (tempPageIndex <= 0)
                {
                    tempPageIndex = 1;
                }
                if (tempPageIndex > pageCount)
                {
                    tempPageIndex = pageCount;
                }
                this.CustomPageIndex = tempPageIndex - 1;
                this.OnPageChanged(sender, e);
            }
            else
            {
                txtPageIndex.Text = (this.CustomPageIndex + 1).ToString();
            }
        }

        void ddlPageIndex_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList ddlPagePerCount = sender as DropDownList;
            if (!string.IsNullOrEmpty(ddlPagePerCount.SelectedValue))
            {
                this.PageIndex = int.Parse(ddlPagePerCount.SelectedValue);
            }
            this.CustomPageIndex = int.Parse(ddlPagePerCount.SelectedValue);

            this.OnPageChanged(sender, e);
            ddlPagePerCount.SelectedIndex = CustomPageIndex;
        }

        void ddlPagePerCount_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList ddlPagePerCount = sender as DropDownList;
            if (!string.IsNullOrEmpty(ddlPagePerCount.SelectedValue))
            {
                this.PageSize = int.Parse(ddlPagePerCount.SelectedValue);
            }
            this.CustomPageIndex = 0;
            this.OnPageChanged(sender, e);
        }

        /// <summary>
        /// delegate for event PageChanged
        /// </summary>
        /// <remarks>
        /// use for paging
        /// </remarks>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public delegate void PageChangedHandler(object sender, EventArgs e);

        private static readonly object pageChangedEventKey = new object();
        public event PageChangedHandler PageChanged
        {
            add
            {
                Events.AddHandler(pageChangedEventKey, value);
            }
            remove
            {
                Events.RemoveHandler(pageChangedEventKey, value);
            }
        }
        public virtual void OnPageChanged(object sender, EventArgs e)
        {
            PageChangedHandler handler = Events[pageChangedEventKey] as PageChangedHandler;
            if (handler != null)
            {
                handler(sender, e);
            }
        }
    }
}

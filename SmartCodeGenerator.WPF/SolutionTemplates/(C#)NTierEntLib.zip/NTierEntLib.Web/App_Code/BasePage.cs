﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web; 
using System.Web.UI;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for BasePage
/// </summary>
public class BasePage:System.Web.UI.Page
{    
    protected override void OnPreLoad(EventArgs e)
    {        
        base.OnPreLoad(e);
    }

    protected override void OnInit(EventArgs e)
    {
        //if (this.CurrentUser == null) Response.Redirect(BY.SmartEMS.Common.CommonHelper.GetRootURI() + "/login.aspx");
        base.OnInit(e);
    }

    public static string GetAppPath()
    {
        string AppPath = "";
        HttpContext HttpCurrent = HttpContext.Current;
        HttpRequest Req;
        if (HttpCurrent != null)
        {
            Req = HttpCurrent.Request;

            string UrlAuthority = Req.Url.GetLeftPart(UriPartial.Authority);
            if (Req.ApplicationPath == null || Req.ApplicationPath == "/") 
                AppPath = UrlAuthority;
            else 
                AppPath = UrlAuthority + Req.ApplicationPath;
        }
        return AppPath;
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Web.UI;
using System.Drawing.Design;
using System.Drawing.Drawing2D;

namespace HP.Web.Controls
{
    [Serializable]
    public class SmartPicture
    {
        private Unit height = 16;

        private string src = string.Empty;
        [NotifyParentProperty(true)]
        [Browsable(true), Bindable(true), Description("图片路径"), Category("Appearance")]
        [Editor("System.Web.UI.Design.ImageUrlEditor, System.Design, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a", typeof(UITypeEditor))]
        public string Src
        {
            get { return this.src; }
            set { this.src = value; }
        }
        [DefaultValue(typeof(Unit), "16px")]
        [NotifyParentProperty(true)]
        public Unit Height
        {
            get { return height; }
            set { height = value; }
        }
        private Unit width = 16;
        [NotifyParentProperty(true)]
        [DefaultValue(typeof(Unit), "16px")]
        public Unit Width
        {
            get { return width; }
            set { width = value; }
        }


        public enum Align { Left, Right }

    }

    [Serializable]
    public class SmartLabel
    {
        private string text = string.Empty;
        [NotifyParentProperty(true)]
        public string Text
        {
            get { return text; }
            set { text = value; }
        }
        private System.Drawing.Font fontFamily = new System.Drawing.Font("宋体", 8);
        private string fontColor = "#000000";

        [NotifyParentProperty(true)]
        public System.Drawing.Font Font
        {
            get { return this.fontFamily; }
            set { this.fontFamily = value; }
        }

        public string FontColor
        {
            get { return this.fontColor; }
            set { this.fontColor = value; }
        }
    }

    [PersistChildren(false)]
    [ParseChildren(true)]
    public class BYImageButton : Control, INamingContainer, IPostBackEventHandler
    {
        public enum RaiseEventType { Client, Server, ClientServer }
        private SmartPicture pic = new SmartPicture();
        private SmartPicture.Align picAlign = SmartPicture.Align.Left;
        private SmartLabel label = new SmartLabel();
        private string jsFunction = string.Empty;
        private static readonly object clickKey = new object();
        public enum TextAlign { Left, Center, Right }
        [Browsable(true), Bindable(true), Description("javascript 方法"), Category("Action")]
        public string JSFunction
        {
            get { return this.jsFunction; }
            set { this.jsFunction = value; }
        }

        private RaiseEventType raiseEvent = RaiseEventType.Server;
        [Browsable(true), Bindable(true), Description("响应事件方式"), Category("Action")]
        public RaiseEventType RaiseEvent
        {
            get { return this.raiseEvent; }
            set { this.raiseEvent = value; }
        }


        private TextAlign align = TextAlign.Left;
        [Browsable(true), Bindable(true), Description("文字的对齐方式"), Category("Appearance")]
        public TextAlign ALign
        {
            get { return align; }
            set { align = value; }

        }
        private Unit width = 80;
        [Browsable(true), Bindable(true), Description("控件宽度"), Category("Appearance")]
        [DefaultValue(typeof(Unit), "80px")]
        public Unit Width
        {
            get { return this.width; }
            set { this.width = value; }
        }

        private string permissionkey = string.Empty;
        [Browsable(true), Bindable(true), Description("权限设置"), Category("Appearance")]
        [DefaultValue(typeof(string), "")]
        public string Permissionkey
        {
            get { return permissionkey; }
            set { permissionkey = value; }
        }

        [Browsable(true), Bindable(true), Category("Action")]
        public event EventHandler OnClick
        {
            add
            {
                Events.AddHandler(clickKey, value);
            }
            remove
            {
                Events.RemoveHandler(clickKey, value);
            }
        }
        [Browsable(true), Bindable(true), Description("图片类"), Category("Appearance")]
        public SmartPicture.Align PicAlign
        {
            get { return picAlign; }
            set { picAlign = value; }
        }

        [Browsable(true), Bindable(true), Description("图片类"), Category("Appearance")]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        [TypeConverter(typeof(ExpandableObjectConverter))]
        [PersistenceMode(PersistenceMode.InnerProperty)]
        public SmartPicture Pic
        {
            get { return pic; }

        }
        [Browsable(true), Bindable(true), Description("文字类"), Category("Appearance")]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        [TypeConverter(typeof(ExpandableObjectConverter))]
        [PersistenceMode(PersistenceMode.InnerProperty)]
        public SmartLabel Label
        {
            get { return label; }

        }

        private bool enable = true;
        [Browsable(true), Bindable(true), Description("Enable"), Category("Appearance")]
        [DefaultValue(typeof(bool), "true")]
        public bool Enable
        {
            get { return enable; }
            set { enable = value; }
        }

        protected override void Render(HtmlTextWriter writer)
        {
            if (raiseEvent == RaiseEventType.Server)
            {
                writer.AddAttribute(HtmlTextWriterAttribute.Onclick, Page.GetPostBackEventReference(this, this.ClientID));
            }
            else if (raiseEvent == RaiseEventType.Client)
            {
                writer.AddAttribute(HtmlTextWriterAttribute.Onclick, "javascript:" + this.jsFunction);
            }
            else
            {
                writer.AddAttribute(HtmlTextWriterAttribute.Onclick, "javascript:if(" + this.jsFunction + "){" + Page.GetPostBackEventReference(this, this.ClientID) + ";}");
                //writer.AddAttribute(HtmlTextWriterAttribute.Onclick, Page.GetPostBackEventReference(this, this.ClientID));
            }

            writer.AddStyleAttribute(HtmlTextWriterStyle.Cursor, "hand");
            writer.AddStyleAttribute(HtmlTextWriterStyle.Width, this.width.Value.ToString() + "px");
            if (align == TextAlign.Left)
            {
                writer.AddStyleAttribute(HtmlTextWriterStyle.TextAlign, "left");
            }
            else if (align == TextAlign.Center)
            {
                writer.AddStyleAttribute(HtmlTextWriterStyle.TextAlign, "center");
            }
            else
            {
                writer.AddStyleAttribute(HtmlTextWriterStyle.TextAlign, "right");
            }
            writer.AddStyleAttribute(HtmlTextWriterStyle.VerticalAlign, "Middle");
            writer.RenderBeginTag(HtmlTextWriterTag.Div);
            if (!this.Enable)
            {
                writer.AddStyleAttribute(HtmlTextWriterStyle.Display, "none");
            }

            writer.RenderBeginTag(HtmlTextWriterTag.Table);
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);
            if (PicAlign == SmartPicture.Align.Left)
            {
                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                AddPic(writer);
                writer.RenderEndTag();
                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                AddLabel(writer);
                writer.RenderEndTag();
            }
            else
            {
                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                AddLabel(writer);
                writer.RenderEndTag();
                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                AddPic(writer);
                writer.RenderEndTag();
            }
            writer.RenderEndTag();
            writer.RenderEndTag();
            writer.RenderEndTag();
            //base.Render(writer);
        }
        private void AddPic(HtmlTextWriter writer)
        {

            writer.AddAttribute(HtmlTextWriterAttribute.Src, base.ResolveClientUrl(pic.Src));
            writer.AddAttribute(HtmlTextWriterAttribute.Height, pic.Height.ToString());
            writer.AddAttribute(HtmlTextWriterAttribute.Width, pic.Width.ToString());

            writer.RenderBeginTag(HtmlTextWriterTag.Img);
            writer.RenderEndTag();
            // writer.Write("<image src='"+this.Src+"' height="+pic.Height+" width="+pic.Width+" />"); 
        }
        private void AddLabel(HtmlTextWriter writer)
        {
            writer.AddStyleAttribute(HtmlTextWriterStyle.VerticalAlign, "middle");
            writer.AddStyleAttribute(HtmlTextWriterStyle.FontSize, label.Font.Size.ToString() + "pt");
            writer.AddStyleAttribute(HtmlTextWriterStyle.FontFamily, label.Font.FontFamily.Name);
            writer.AddStyleAttribute(HtmlTextWriterStyle.Color, label.FontColor);

            if (label.Font.Bold)
            {

                writer.AddStyleAttribute(HtmlTextWriterStyle.FontWeight, "Bold");
            }
            writer.RenderBeginTag(HtmlTextWriterTag.Label);

            writer.Write(label.Text == string.Empty ? this.ClientID.ToString() : label.Text);
            writer.RenderEndTag();
            //writer.Write("<label>" + Label.Text + "</label>");
        }


        #region IPostBackEventHandler 成员

        public void RaisePostBackEvent(string eventArgument)
        {
            EventHandler e = (EventHandler)Events[clickKey];
            if (e != null)
            {
                e(this, EventArgs.Empty);
            }
        }

        #endregion
    }

}

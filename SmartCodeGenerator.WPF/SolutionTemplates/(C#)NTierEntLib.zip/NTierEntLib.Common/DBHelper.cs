 
 
//  Copyright © Hewlett-Packard Company. All Rights Reserved.
// </copyright>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Configuration;

namespace NTierEntLib.Common
{
    public static class DBHelper
    {
        /// <summary>
        /// Get Database Object
        /// </summary>
        /// <param name="name">Database instance name</param>
        /// <returns>Database Object</returns>
        public static Database CreateDataBase()
        {
            return DatabaseFactory.CreateDatabase(); 
        }
        /// <summary>
        /// Get Database Object
        /// </summary>
        /// <param name="name">Database instance name</param>
        /// <returns>Database Object</returns>
        public static Database CreateDataBase(string name = "")
        {
            return DatabaseFactory.CreateDatabase(name);
            //return EnterpriseLibraryContainer.Current.GetInstance<Database>(name);
        }
    }
}


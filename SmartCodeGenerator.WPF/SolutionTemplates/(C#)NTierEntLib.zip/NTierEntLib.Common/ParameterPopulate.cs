 
 
//  Copyright © Hewlett-Packard Company. All Rights Reserved.
// </copyright>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace NTierEntLib.Common
{
        public class ParameterPopulate
        {
			public string ParName
			{
				get;
				set;
			}
			public DbType ParDbType
			{
				get;
				set;
			}
			public object ParValue
			{
				get;
				set;
			}
			public OptType ParOptType
			{
				get;
				set;
			}            
        } 
		
		public enum OptType
		{
			FuzzyQuery, 
			PreciseQuery, 
			GreaterThan, 
			NoGreaterThan, 
			LessThan, 
			NoLessThan 
		}
}
